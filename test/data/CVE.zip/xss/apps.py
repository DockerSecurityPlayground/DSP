from django.apps import AppConfig


class XssConfig(AppConfig):
    name = 'xss'
